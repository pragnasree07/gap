//package com.oms.mini_oms.service;
//
//import com.oms.mini_oms.model.CanceledOrder;
//import com.oms.mini_oms.model.Order;
//import com.oms.mini_oms.model.OrderStatus;
//import com.oms.mini_oms.repository.CanceledOrderRepository;
//import com.oms.mini_oms.repository.OrderRepository;
//import jakarta.transaction.Transactional;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Service;
//
//import java.time.LocalDateTime;
//import java.util.List;
//
//import static com.oms.mini_oms.model.OrderStatus.CANCELED;
//
//@Service
//public class OrderSchedulerService {
//
//    @Autowired
//    private OrderRepository orderRepository;
//
//    @Autowired
//    private CanceledOrderRepository canceledOrderRepository;
//
//    @Scheduled(cron = "0 * * * * *")  // Runs every 1 minute
//    @Transactional
//    public void moveCanceledOrders() {
//        List<Order> canceledOrders = orderRepository.findByStatus(OrderStatus.CANCELED);
//
//        for (Order order : canceledOrders) {
//            if (!order.isProcessed()) {
//                CanceledOrder canceledOrder = new CanceledOrder();
//                canceledOrder.setOrderId(order.getId());
//                canceledOrder.setReason("Manually Cancelled");
//                canceledOrder.setCanceledAt(LocalDateTime.now());
//                order.setProcessed(true);
//
//                canceledOrderRepository.save(canceledOrder);
//            }
//        }
//    }
//}
