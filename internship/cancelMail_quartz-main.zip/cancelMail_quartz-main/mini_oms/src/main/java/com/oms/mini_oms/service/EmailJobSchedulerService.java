package com.oms.mini_oms.service;

import com.oms.mini_oms.job.CancelledOrderEmailJob;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmailJobSchedulerService {

    @Autowired
    private final Scheduler scheduler;
    @Autowired
    public EmailJobSchedulerService(Scheduler scheduler) {
        this.scheduler = scheduler;
    }

    public void scheduleEmailJob() throws SchedulerException {
        JobKey jobKey = new JobKey("cancelledOrderEmailJob", "email-group");
        TriggerKey triggerKey = new TriggerKey("cancelledOrderEmailTrigger", "email-group");


        if (scheduler == null) {
            throw new IllegalStateException("Scheduler is null!");
        }
        if (scheduler.checkExists(jobKey)) {
            System.out.println("Job exists. Rescheduling...");

            Trigger newTrigger = TriggerBuilder.newTrigger()
                    .withIdentity(triggerKey)
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                            .withIntervalInMinutes(1) // Adjust as needed
                            .repeatForever())
                    .build();

            scheduler.rescheduleJob(triggerKey, newTrigger); // Reschedules existing job
        } else {
            System.out.println("Job does not exist. Scheduling a new one...");

            JobDetail jobDetail = JobBuilder.newJob(CancelledOrderEmailJob.class)
                    .withIdentity(jobKey)
                    .storeDurably()
                    .build();

            Trigger trigger = TriggerBuilder.newTrigger()
                    .withIdentity(triggerKey)
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                            .withIntervalInMinutes(1)
                            .repeatForever())
                    .build();

            scheduler.scheduleJob(jobDetail, trigger);
        }
    }
}

