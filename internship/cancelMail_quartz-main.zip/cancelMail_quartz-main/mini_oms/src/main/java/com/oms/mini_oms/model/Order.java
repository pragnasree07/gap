package com.oms.mini_oms.model;

import jakarta.persistence.*;
import jakarta.transaction.Transactional;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // New fields
    private String customerName;
    private String customerEmail;
    private double price;
    private int quantity;

    private String status; // e.g., NEW, CANCELED, etc.
    private LocalDateTime orderDate;
}

