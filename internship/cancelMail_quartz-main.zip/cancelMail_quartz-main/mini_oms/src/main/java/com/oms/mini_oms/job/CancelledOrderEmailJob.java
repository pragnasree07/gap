package com.oms.mini_oms.job;

import com.oms.mini_oms.model.CanceledOrder;
import com.oms.mini_oms.repository.CanceledOrderRepository;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.List;

@Component
public class CancelledOrderEmailJob extends QuartzJobBean {
    private static final Logger logger = LoggerFactory.getLogger(CancelledOrderEmailJob.class);

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private CanceledOrderRepository cancelledOrderRepository;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        List<CanceledOrder> orders = cancelledOrderRepository.findByNotifiedFalse();
        for (CanceledOrder order : orders) {
            try {
                sendEmail(order);
                order.setNotified(true);
                cancelledOrderRepository.save(order);
            } catch (Exception e) {
                logger.error("Error sending email for order " + order.getOrderId(), e);
            }
        }
    }

    private void sendEmail(CanceledOrder order) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, StandardCharsets.UTF_8.toString());
        helper.setSubject("Your Order Has Been Cancelled");

        String text = "Dear " + order.getCustomerName() + ",<br/><br/>" +
                "We regret to inform you that your order has been cancelled.<br/>" +
                "Order ID: " + order.getOrderId() + "<br/>" +
                "Price: " + order.getPrice() + "<br/>" +
                "Quantity: " + order.getQuantity() + "<br/><br/>" +
                "Thank you.";
        helper.setText(text, true);
        helper.setFrom("pragnapallam0210@gmail.com");  // Update with your sender email
        helper.setTo(order.getCustomerEmail());

        mailSender.send(message);
    }
}
