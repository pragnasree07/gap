//package com.oms.mini_oms.config;
//import com.oms.mini_oms.config.JobInitializer;
//import jakarta.annotation.PostConstruct;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.ApplicationRunner;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import com.oms.mini_oms.service.EmailJobSchedulerService;
//
//@Configuration
//public class JobInitializer {
//    private final EmailJobSchedulerService jobSchedulerService;
////
//    @Autowired
//    public JobInitializer(EmailJobSchedulerService jobSchedulerService) {
//        this.jobSchedulerService = jobSchedulerService;
//    }
//
//    @PostConstruct
//    public void scheduleJobOnStartup() {
//        jobSchedulerService.scheduleEmailJob();  //  Called properly using an instance
//    }
//}
//
