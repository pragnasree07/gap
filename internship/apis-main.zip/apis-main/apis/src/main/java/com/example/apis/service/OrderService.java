package com.example.apis.service;

import com.example.apis.model.CanceledOrder;
import com.example.apis.model.Order;
import com.example.apis.repository.CanceledOrderRepository;
import com.example.apis.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CanceledOrderRepository canceledOrderRepository;

    public Order createOrder(Order order) {
        order.setStatus("NEW");
        order.setOrderDate(LocalDateTime.now());
        return orderRepository.save(order);
    }

    public Order getOrder(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order updateOrder(Long id, Order updatedOrder) {
        Order order = getOrder(id);
        order.setCustomerName(updatedOrder.getCustomerName());
        order.setCustomerEmail(updatedOrder.getCustomerEmail());
        order.setPrice(updatedOrder.getPrice());
        order.setQuantity(updatedOrder.getQuantity());
        order.setStatus(updatedOrder.getStatus());
        return orderRepository.save(order);
    }

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }

    // Cancel an order and record cancellation details
    public Order cancelOrder(Long orderId) {
        Order order = getOrder(orderId);
        // Use "CANCELED" (with one L) for consistency with our enum
        order.setStatus("CANCELED");
        orderRepository.save(order);

        CanceledOrder canceledOrder = new CanceledOrder();
        canceledOrder.setOrderId(order.getId());
        canceledOrder.setCustomerName(order.getCustomerName());
        canceledOrder.setCustomerEmail(order.getCustomerEmail());
        canceledOrder.setPrice(order.getPrice());
        canceledOrder.setQuantity(order.getQuantity());
        canceledOrder.setCancelledAt(LocalDateTime.now());
        canceledOrder.setNotified(false);
        canceledOrderRepository.save(canceledOrder);

        return order;
    }
}


//package com.example.apis.service;
//
//import com.example.apis.model.CanceledOrder;
//import com.example.apis.model.Order;
//import com.example.apis.repository.CanceledOrderRepository;
//import com.example.apis.repository.OrderRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.time.LocalDateTime;
//import java.util.List;
//
//@Service
//public class OrderService {
//
//    @Autowired
//    private OrderRepository orderRepository;
//
//    @Autowired
//    private CanceledOrderRepository cancelledOrderRepository;
//
//    public Order createOrder(Order order) {
//        order.setStatus("NEW");
//        order.setOrderDate(LocalDateTime.now());
//        return orderRepository.save(order);
//    }
//
//    public Order getOrder(Long id) {
//        return orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
//    }
//
//    public List<Order> getAllOrders() {
//        return orderRepository.findAll();
//    }
//
//    public Order updateOrder(Long id, Order updatedOrder) {
//        Order order = getOrder(id);
//        order.setCustomerName(updatedOrder.getCustomerName());
//        order.setCustomerEmail(updatedOrder.getCustomerEmail());
//        order.setPrice(updatedOrder.getPrice());
//        order.setQuantity(updatedOrder.getQuantity());
//        order.setStatus(updatedOrder.getStatus());
//        return orderRepository.save(order);
//    }
//
//    public void deleteOrder(Long id) {
//        orderRepository.deleteById(id);
//    }
//
//    // Cancel an order and record cancellation details
//    public Order cancelOrder(Long orderId) {
//        Order order = getOrder(orderId);
//        order.setStatus("CANCELLED");
//        orderRepository.save(order);
//
//        CanceledOrder cancelledOrder = new CanceledOrder();
//        cancelledOrder.setOrderId(order.getId());
//        cancelledOrder.setCustomerName(order.getCustomerName());
//        cancelledOrder.setCustomerEmail(order.getCustomerEmail());
//        cancelledOrder.setPrice(order.getPrice());
//        cancelledOrder.setQuantity(order.getQuantity());
//        cancelledOrder.setCancelledAt(LocalDateTime.now());
//        cancelledOrder.setNotified(false);
//        cancelledOrderRepository.save(cancelledOrder);
//
//        return order;
//    }
//}