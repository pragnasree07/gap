package com.example.apis.repository;

import com.example.apis.model.CanceledOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CanceledOrderRepository extends JpaRepository<CanceledOrder, Long> {
    boolean existsByOrderId(Long orderId);  // Check for duplicate records
    List<CanceledOrder> findByNotifiedFalse();
}


//package com.example.apis.repository;
//
//import com.example.apis.model.CanceledOrder;
//import com.example.apis.model.Order;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository
//
//public interface CanceledOrderRepository extends JpaRepository<CanceledOrder, Long> {
//    boolean existsByOrderId(Long orderId);  // Check for duplicate records
//    List<CanceledOrder> findByNotifiedFalse();
//}