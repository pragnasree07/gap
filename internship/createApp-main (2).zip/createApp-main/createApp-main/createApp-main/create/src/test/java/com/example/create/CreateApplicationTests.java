package com.example.create;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreateApplicationTests {

	@Test
	void contextLoads() {
	}

}
