package com.example.create.model;

public enum ServiceStatus {
    NOT_STARTED, FAILED, DONE
}