package com.example.create.model;

public enum EntityStatus {
    CREATED, IN_PROGRESS, FAILED, CONFIRMED
}