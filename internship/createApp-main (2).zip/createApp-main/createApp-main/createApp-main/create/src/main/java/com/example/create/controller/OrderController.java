package com.example.create.controller;

import com.example.create.model.Order;
import com.example.create.repository.OrderRepository;
import com.example.create.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private OrderRepository orderRepository;

    @PostMapping("/create")
    public Order createOrder(@RequestBody Order order) {
        orderRepository.save(order);
        return orderService.processOrder(order);
    }

    @PostMapping("/process/{id}")
    public Order processOrder(@PathVariable Long id) {
        Order order = orderRepository.findById(id).orElseThrow();
        return orderService.processOrder(order);
    }

    @GetMapping("/pending")
    public List<Order> getPendingOrders() {
        return orderRepository.findAll(); // Adjust this based on your new logic
    }
}
