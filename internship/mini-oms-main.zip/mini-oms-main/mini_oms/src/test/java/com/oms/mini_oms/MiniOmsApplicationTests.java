package com.oms.mini_oms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniOmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
