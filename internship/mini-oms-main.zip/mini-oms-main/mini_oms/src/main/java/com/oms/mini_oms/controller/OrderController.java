package com.oms.mini_oms.controller;

import com.oms.mini_oms.model.Order;
import com.oms.mini_oms.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        Order created = orderService.createOrder(order);
        return ResponseEntity.ok(created);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrder(@PathVariable Long id) {
        Order order = orderService.getOrder(id);
        return ResponseEntity.ok(order);
    }

    @GetMapping
    public ResponseEntity<List<Order>> getAllOrders() {
        List<Order> orders = orderService.getAllOrders();
        return ResponseEntity.ok(orders);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Order> updateOrder(@PathVariable Long id, @RequestBody Order order) {
        Order updated = orderService.updateOrder(id, order);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<String> cancelOrder(@PathVariable Long id) {
        Order cancelled = orderService.cancelOrder(id);
        return ResponseEntity.ok("Order " + cancelled.getId() + " has been cancelled.");
    }
}
//import org.hibernate.query.Order;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;

//@RestController
//@RequestMapping("/api/orders")
//public class OrderController {
//
//    @Autowired
//    private OrderService orderService;
//
//    @GetMapping
//    public List<Order> getAllOrders() {
//        return orderService.getAllOrders();
//    }
//
//@GetMapping("/{id}")
//public Order getOrder(@PathVariable Long id) {
//    return orderService.getOrderById(id);
//}
//
//    @PostMapping
//    public Order createOrder(@RequestBody Order order)
//    {
//        return orderService.createOrder(order);
//    }
//
//    @PutMapping("/{id}")
//    public ResponseEntity<Order> updateOrder(@PathVariable Long id, @RequestBody Order orderDetails) {
//        try {
//            return ResponseEntity.ok(orderService.updateOrder(id, orderDetails));
//        } catch (RuntimeException e) {
//            return ResponseEntity.notFound().build();
//        }
//    }
//
//
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteOrder(@PathVariable Long id) {
//        orderService.deleteOrder(id);
//        return ResponseEntity.noContent().build();
//    }
//    @PostMapping("/{orderId}/cancel")
//    public ResponseEntity<String> cancelOrder(@PathVariable Long orderId) {
//        boolean success = orderService.cancelOrder(orderId);
//        if (success) {
//            return ResponseEntity.ok("Order canceled successfully.");
//        }
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Order not found or cannot be canceled.");
//    }
//
//    @RestController
//    public static class HomeController {
//        @RequestMapping("/")
//        public String greet() {
//            return "Order Management System(oms)";
//        }
//    }
//}
//
//
