package com.oms.mini_oms.service;

import com.oms.mini_oms.job.CancelledOrderEmailJob;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmailJobSchedulerService {

    @Autowired
    private Scheduler scheduler;

    public void scheduleEmailJob() throws SchedulerException {
        JobKey jobKey = new JobKey("cancelledOrderEmailJob", "email-group");
        TriggerKey triggerKey = new TriggerKey("cancelledOrderEmailTrigger", "email-group");


        if (scheduler.checkExists(jobKey)) {
            System.out.println("Job exists. Rescheduling...");

            Trigger newTrigger = TriggerBuilder.newTrigger()
                    .withIdentity(triggerKey)
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                            .withIntervalInMinutes(1) // Adjust as needed
                            .repeatForever())
                    .build();

            scheduler.rescheduleJob(triggerKey, newTrigger); // Reschedules existing job
        } else {
            System.out.println("Job does not exist. Scheduling a new one...");

            JobDetail jobDetail = JobBuilder.newJob(CancelledOrderEmailJob.class)
                    .withIdentity(jobKey)
                    .storeDurably()
                    .build();

            Trigger trigger = TriggerBuilder.newTrigger()
                    .withIdentity(triggerKey)
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                            .withIntervalInMinutes(10)
                            .repeatForever())
                    .build();

            scheduler.scheduleJob(jobDetail, trigger);
        }
    }
}

//package com.oms.mini_oms.service;
//
//import com.oms.mini_oms.job.CancelledOrderEmailJob;
//import jakarta.annotation.PostConstruct;
//import org.quartz.*;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//@Service
//public class EmailJobSchedulerService {
//
//    @Autowired
//    private Scheduler scheduler;
//
//    @PostConstruct
//    public void scheduleEmailJob() throws SchedulerException {
//        JobDetail jobDetail = JobBuilder.newJob(CancelledOrderEmailJob.class)
//                .withIdentity("cancelledOrderEmailJob", "email-group")
//                .storeDurably()
//                .build();
//
//        Trigger trigger = TriggerBuilder.newTrigger()
//                .forJob(jobDetail)
//                .withIdentity("cancelledOrderEmailTrigger", "email-group")
//                .withSchedule(SimpleScheduleBuilder.simpleSchedule()
//                        .withIntervalInMinutes(1)  // check every minute
//                        .repeatForever()
//                        .withMisfireHandlingInstructionFireNow())
//                .build();
//
//        scheduler.scheduleJob(jobDetail, trigger);
//    }
//}
