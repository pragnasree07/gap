package com.oms.mini_oms.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
@Setter
@Getter
@Entity
@Table(name = "canceled_orders")
public class CanceledOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Reference to the original order id
    private Long orderId;

    // Order details
    private String customerName;
    private String customerEmail;
    private double price;
    private int quantity;

    private LocalDateTime cancelledAt;

    // Indicates whether a notification email has been sent
    private boolean notified = false;
}
//@Entity
//@Table(name = "canceled_orders")
//public class CanceledOrder {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    private Long orderId;
//    private String customerName;
//    private String reason;
//    private LocalDateTime canceledAt;
//
//    // Constructors, Getters, Setters
//
//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public Long getOrderId() {
//        return orderId;
//    }
//
//    public void setOrderId(Long orderId) {
//        this.orderId = orderId;
//    }
//
//    public String getCustomerName() {
//        return customerName;
//    }
//
//    public void setCustomerName(String customerName) {
//        this.customerName = customerName;
//    }
//
//    public String getReason() {
//        return reason;
//    }
//
//    public void setReason(String reason) {
//        this.reason = reason;
//    }
//
//    public LocalDateTime getCanceledAt() {
//        return canceledAt;
//    }
//
//    public void setCanceledAt(LocalDateTime canceledAt) {
//        this.canceledAt = canceledAt;
//    }
//
//    @Override
//    public String toString() {
//        return "CanceledOrder{" +
//                "id=" + id +
//                ", orderId=" + orderId +
//                ", customerName='" + customerName + '\'' +
//                ", reason='" + reason + '\'' +
//                ", canceledAt=" + canceledAt +
//                '}';
//    }
//}
//
