package com.oms.mini_oms.service;

import com.oms.mini_oms.exception.OrderNotFoundException;
import com.oms.mini_oms.model.CanceledOrder;
import com.oms.mini_oms.model.Order;
import com.oms.mini_oms.model.OrderStatus;
import com.oms.mini_oms.repository.CanceledOrderRepository;
import com.oms.mini_oms.repository.OrderRepository;
import com.oms.mini_oms.repository.OrderRepository;
import jakarta.transaction.Transactional;
//import org.hibernate.query.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CanceledOrderRepository cancelledOrderRepository;

    public Order createOrder(Order order) {
        order.setStatus("NEW");
        order.setOrderDate(LocalDateTime.now());
        return orderRepository.save(order);
    }

    public Order getOrder(Long id) {
        return orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order updateOrder(Long id, Order updatedOrder) {
        Order order = getOrder(id);
        order.setCustomerName(updatedOrder.getCustomerName());
        order.setCustomerEmail(updatedOrder.getCustomerEmail());
        order.setPrice(updatedOrder.getPrice());
        order.setQuantity(updatedOrder.getQuantity());
        order.setStatus(updatedOrder.getStatus());
        return orderRepository.save(order);
    }

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }

    // Cancel an order and record cancellation details
    public Order cancelOrder(Long orderId) {
        Order order = getOrder(orderId);
        order.setStatus("CANCELLED");
        orderRepository.save(order);

        CanceledOrder cancelledOrder = new CanceledOrder();
        cancelledOrder.setOrderId(order.getId());
        cancelledOrder.setCustomerName(order.getCustomerName());
        cancelledOrder.setCustomerEmail(order.getCustomerEmail());
        cancelledOrder.setPrice(order.getPrice());
        cancelledOrder.setQuantity(order.getQuantity());
        cancelledOrder.setCancelledAt(LocalDateTime.now());
        cancelledOrder.setNotified(false);
        cancelledOrderRepository.save(cancelledOrder);

        return order;
    }
}

//@Service
//public class OrderService {
//
//    @Autowired
//    private OrderRepository orderRepository;
//    @Autowired
//    private CanceledOrderRepository canceledOrderRepository;
//
//    public List<Order> getAllOrders() {
//        return orderRepository.findAll();
//    }
//
//    public Order getOrderById(Long id) {
//        return orderRepository.findById(id)
//                .orElseThrow(() -> new OrderNotFoundException("Order with ID " + id + " not found"));
//    }
//
//
//    public Order createOrder(Order order) {
//
//        return orderRepository.save(order);
//    }
//
//    public Order updateOrder(Long id, Order orderDetails) {
//        return orderRepository.findById(id).map(order -> {
//            order.setCustomerName(orderDetails.getCustomerName());
//            order.setQuantity(orderDetails.getQuantity());
//            order.setPrice(orderDetails.getPrice());
//            return orderRepository.save(order);
//        }).orElseThrow(() -> new RuntimeException("Order not found"));
//    }
//
//    public void deleteOrder(Long id) {
//        orderRepository.deleteById(id);
//    }
//
//public boolean cancelOrder(Long orderId) {
//    Order order = orderRepository.findById(orderId)
//            .orElseThrow(() -> new RuntimeException("Order not found"));
//
//    order.setStatus("CANCELED");
//    orderRepository.save(order);
//
//    // Record cancellation in cancelled_orders table
//    CanceledOrder cancelledOrder = new CanceledOrder();
//    cancelledOrder.setOrderId(order.getId());
//    cancelledOrder.setCustomerEmail(order.getCustomerEmail());
//    cancelledOrder.setCancelledAt(LocalDateTime.now());
//    cancelledOrder.setNotified(false);
//
//    // Use repository to save the entity
//    canceledOrderRepository.save(cancelledOrder);
//
//    return true; // Return boolean instead of Order
//}
//
//}
//
//
//
//
