package com.oms.mini_oms.repository;

import com.oms.mini_oms.model.CanceledOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public interface CanceledOrderRepository extends JpaRepository<CanceledOrder, Long> {
    boolean existsByOrderId(Long orderId);  // Check for duplicate records
    List<CanceledOrder> findByNotifiedFalse();
}


