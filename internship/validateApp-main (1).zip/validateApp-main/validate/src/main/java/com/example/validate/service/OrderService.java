package com.example.validate.service;

import com.example.validate.model.Order;
import com.example.validate.model.OrderState;
import com.example.validate.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {
    @Autowired
    private OrderRepository orderRepository;

    public Order processOrder(Order order) {
        switch (order.getState()) {
            case PENDING_VALIDATION_1:
                if (task1(order)) {
                    order.setState(OrderState.PENDING_VALIDATION_2);
                    orderRepository.save(order);
                }
                return order; // Exit function after updating state

            case PENDING_VALIDATION_2:
                if (task2(order)) {
                    order.setState(OrderState.VALIDATED);
                    orderRepository.save(order);
                    System.out.print("order validated");

                }
                return order; // Exit function after updating state

            default:
                return order; // Return order as is if state is not pending
        }
    }


    private boolean task1(Order order) {
        System.out.println("Executing Task 1: vadilating task 1...");
//        if (random.nextBoolean()) { // 50% chance of failure
        if (Math.random() < 0.3) {
            System.out.println("Task 1 Failed!");
            return false;
        }
        System.out.println("task1 validated");
        order.setOrderNumber(System.currentTimeMillis());
        return true;
    }

    private boolean task2(Order order) {
        System.out.println("Executing Task 2: validating task2 ...");
        if (Math.random() < 0.3) {
            System.out.println("Task 2 Failed!");
            return false;


        }
        System.out.println("task2 validated");
        return true;
    }
}




//@Service
//public class OrderService {
//    @Autowired
//    private OrderRepository orderRepository;
//
//    private final Random random = new Random();
//
//    public Order processOrder(Order order) {
//        switch (order.getState()) {
//            case PENDING_VALIDATION_1:
//                if (StartPackaging(order)) {
//                    order.setState(OrderState.PENDING_VALIDATION_2);
//                } else {
//                    return order; // Stay in PENDING_VALIDATION_1
//                }
//            case PENDING_VALIDATION_2:
//                if (FinalConfirmation(order)) {
//                    order.setState(OrderState.VALIDATED);
//                } else {
//                    return order; // Stay in PENDING_VALIDATION_2
//                }
//        }
//        orderRepository.save(order);
//        return order;
//    }
//
//    private boolean StartPackaging(Order order) {
//        System.out.println("Executing Task 1: Start Packaging...");
//        if (random.nextBoolean()) { // 50% chance of failure
//            System.out.println("Task 1 Failed!");
//            return false;
//        }
//        return true;
//    }
//
//    private boolean FinalConfirmation(Order order) {
//        System.out.println("Executing Task 2: Final Confirmation...");
//        if (random.nextBoolean()) { // 50% chance of failure
//            System.out.println("Task 2 Failed!");
//            return false;
//        }
//        System.out.print("order validated");
//        return true;
//    }
//}
//
