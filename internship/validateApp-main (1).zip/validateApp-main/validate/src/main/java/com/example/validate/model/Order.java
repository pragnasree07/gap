package com.example.validate.model;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerName;
    private String customerEmail;
    private Long orderNumber;
    private OrderState state;
    @Column(nullable = false)
    private double price;

    @Column(nullable = false)
    private int quantity;
}

