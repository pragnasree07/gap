package com.example.validate.controller;


import com.example.validate.model.Order;
import com.example.validate.model.OrderState;
import com.example.validate.repository.OrderRepository;
import com.example.validate.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/orders")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @Autowired
    private OrderRepository orderRepository;


//@PostMapping("/create")
//public ResponseEntity<Order> createOrder(@RequestBody Order order) {
//    log.info("Received order: {}", order);
//    //orderRepository.save(order);
//    //Order savedOrder = orderRepository.save(order);
//    return ResponseEntity.ok(order);
//}
@PostMapping("/create")
public ResponseEntity<Order> createOrder(@RequestBody Order order) {
    log.info("Received order: {}", order);

    order.setId(null); // Ensures a new record is created in the database
    order.setState(OrderState.PENDING_VALIDATION_1); // Set the initial state for validation

    Order savedOrder = orderRepository.save(order); // Save order in Validate App DB
    return ResponseEntity.ok(savedOrder);
}





    @PostMapping("/process/{id}")
    public Order processOrder(@PathVariable Long id) {

        Order order = orderRepository.findById(id).orElseThrow();

        return orderService.processOrder(order);
    }

    @GetMapping("/pending")
    public List<Order> getPendingOrders() {
        return orderRepository.findByState(OrderState.PENDING_VALIDATION_1);
    }
}

