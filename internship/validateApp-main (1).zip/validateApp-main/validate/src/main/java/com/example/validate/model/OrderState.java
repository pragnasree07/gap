package com.example.validate.model;

public enum OrderState {

    CONFIRMED,
    PENDING_VALIDATION_1,  // Waiting to start packaging
    PENDING_VALIDATION_2,  // Waiting for final confirmation
    VALIDATED              // Order is successfully validated
}

