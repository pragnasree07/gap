package com.example.validate.repository;

import com.example.validate.model.Order;
import com.example.validate.model.OrderState;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
//
//public interface OrderRepository extends JpaRepository<Order, Long> {
//    List<Order> findByState(OrderState state);
//}
//@Repository
//public interface OrderRepository extends JpaRepository<Order, Long> {
//
//    @Override
//    default <S extends Order> S save(S entity) {
//        System.out.println("💾 Saving Order in DB: " + entity);
//        return JpaRepository.super.save(entity);
//    }
//}
@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByState(OrderState state);
}



