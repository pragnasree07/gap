package com.example.validate.scheduler;
import com.example.validate.model.Order;
import com.example.validate.model.OrderState;
import com.example.validate.repository.OrderRepository;
import com.example.validate.service.OrderService;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
public class OrderRetryJob implements Job {
    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderService orderService;

    @Override
    public void execute(JobExecutionContext context) {
        List<Order> failedOrders = orderRepository.findByState(OrderState.PENDING_VALIDATION_1);
        failedOrders.addAll(orderRepository.findByState(OrderState.PENDING_VALIDATION_2));

        for (Order order : failedOrders) {
            System.out.println("Retrying Order ID: " + order.getId());
            orderService.processOrder(order);
        }
    }
}

