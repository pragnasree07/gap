package com.example.email_scheduler.controller;

import com.example.email_scheduler.payload.EmailRequest;
import com.example.email_scheduler.payload.EmailResponse;
import com.example.email_scheduler.service.EmailSchedulerService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
public class EmailSchedulerController {

    @Autowired
    private EmailSchedulerService emailSchedulerService;

    @PostMapping("/scheduleEmail")
    public ResponseEntity<EmailResponse> scheduleEmail(@Valid @RequestBody EmailRequest emailRequest) {
        EmailResponse response = emailSchedulerService.scheduleEmail(emailRequest);
        return ResponseEntity.status(response.isSuccess() ? 200 : 400).body(response);
    }

    @GetMapping("/get")
    public ResponseEntity<String> getApiTest(){
        return ResponseEntity.ok("Get API Test - pass");
    }
}
