package com.example.email_scheduler.service;

import com.example.email_scheduler.payload.EmailRequest;
import com.example.email_scheduler.payload.EmailResponse;
import com.example.email_scheduler.quartz.job.EmailJob;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.UUID;

@Service
public class EmailSchedulerService {

    @Autowired
    private Scheduler scheduler;

    public EmailResponse scheduleEmail(EmailRequest emailRequest) {
        try {
            // Validate timezone
            if (emailRequest.getTimezone() == null) {
                return new EmailResponse(false, "Timezone cannot be null.");
            }
            ZoneId zoneId;
            try {
                zoneId = ZoneId.of(String.valueOf(emailRequest.getTimezone()));
            } catch (Exception e) {
                return new EmailResponse(false, "Invalid timezone provided.");
            }
            ZonedDateTime dateTime = emailRequest.getDateTime().atZone(zoneId);
            if (dateTime.isBefore(ZonedDateTime.now())) {
                return new EmailResponse(false, "Scheduled time must be in the future.");
            }
            JobDetail jobDetail = buildJobDetail(emailRequest);
            Trigger trigger = buildJobTrigger(jobDetail, dateTime);
            scheduler.scheduleJob(jobDetail, trigger);
            return new EmailResponse(true, jobDetail.getKey().getName(), jobDetail.getKey().getGroup(), "Email scheduled successfully");
        } catch (SchedulerException se) {
            // Consider proper logging in a real application
            return new EmailResponse(false, "Error while scheduling email, please try again later");
        }
    }

    private JobDetail buildJobDetail(EmailRequest request) {
        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put("email", request.getEmail());
        jobDataMap.put("subject", request.getSubject());
        jobDataMap.put("body", request.getBody());

        return JobBuilder.newJob(EmailJob.class)
                .withIdentity(UUID.randomUUID().toString(), "email-jobs")
                .usingJobData(jobDataMap)
                .storeDurably()
                .build();
    }

    private Trigger buildJobTrigger(JobDetail jobDetail, ZonedDateTime startAt) {
        return TriggerBuilder.newTrigger()
                .forJob(jobDetail)
                .withIdentity(jobDetail.getKey().getName(), "email-triggers")
                .withDescription("send Email trigger")
                .startAt(Date.from(startAt.toInstant()))
                .withSchedule(SimpleScheduleBuilder.simpleSchedule().withMisfireHandlingInstructionFireNow())
                .build();
    }
}

