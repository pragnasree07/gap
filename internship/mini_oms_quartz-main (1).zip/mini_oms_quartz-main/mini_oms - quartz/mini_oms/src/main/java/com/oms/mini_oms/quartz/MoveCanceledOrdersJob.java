package com.oms.mini_oms.quartz;

import com.oms.mini_oms.model.CanceledOrder;
import com.oms.mini_oms.model.Order;
import com.oms.mini_oms.model.OrderStatus;
import com.oms.mini_oms.repository.CanceledOrderRepository;
import com.oms.mini_oms.repository.OrderRepository;
import com.oms.mini_oms.service.EmailService;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class MoveCanceledOrdersJob implements Job {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CanceledOrderRepository canceledOrderRepository;

    @Autowired
    private EmailService emailService;

    @Override
    public void execute(JobExecutionContext context) {
        // Fetch all orders with status = CANCELED
        List<Order> canceledOrders = orderRepository.findByStatus(OrderStatus.CANCELED);

        for (Order order : canceledOrders) {
            // Only process once if not already processed
            if (!order.isProcessed()) {
                // Create a record in the canceled orders table
                CanceledOrder canceledOrder = new CanceledOrder();
                canceledOrder.setOrderId(order.getId());
                canceledOrder.setCustomerName(order.getCustomerName());
                canceledOrder.setReason("Manually Cancelled");
                canceledOrder.setCanceledAt(LocalDateTime.now());

                // Mark the order as processed so we do not handle it again
                order.setProcessed(true);

                // Save both the canceled record and updated order
                canceledOrderRepository.save(canceledOrder);
                orderRepository.save(order);

                // Send email notification to customer
                emailService.sendOrderCanceledEmail(
                        order.getCustomerEmail(),
                        order.getCustomerName(),
                        order.getId(),
                        canceledOrder.getReason()
                );
            }
        }
    }
}
