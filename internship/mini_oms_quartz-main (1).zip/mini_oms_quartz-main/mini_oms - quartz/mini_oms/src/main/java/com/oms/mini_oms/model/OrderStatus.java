package com.oms.mini_oms.model;

public enum OrderStatus {
    PENDING,
    PROCESSING,
    SHIPPED,
    COMPLETED,
    CANCELED
}

