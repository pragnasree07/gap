package com.oms.mini_oms.config;
import com.oms.mini_oms.quartz.MoveCanceledOrdersJob;
import org.quartz.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class QuartzConfig {

    @Bean
    public JobDetail moveCanceledOrdersJobDetail() {
        return JobBuilder.newJob(MoveCanceledOrdersJob.class)
                .withIdentity("moveCanceledOrdersJob")
                .storeDurably()
                .build();
    }

    @Bean
    public Trigger moveCanceledOrdersTrigger() {
        return TriggerBuilder.newTrigger()
                .forJob(moveCanceledOrdersJobDetail())
                .withIdentity("moveCanceledOrdersTrigger")
                .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                        .withIntervalInMinutes(1) // Runs every minute
                        .repeatForever())
                .build();
    }
}

