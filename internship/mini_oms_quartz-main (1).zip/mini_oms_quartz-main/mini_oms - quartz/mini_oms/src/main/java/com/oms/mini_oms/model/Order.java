package com.oms.mini_oms.model;

import jakarta.persistence.*;
import jakarta.transaction.Transactional;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String customerName;
    private String product;
    private String customerEmail;
    private int quantity;
    private double price;
    @Enumerated(EnumType.STRING) // Stores status as a string (e.g., PENDING, CANCELED)
    private OrderStatus status;
    private boolean isProcessed;

    public boolean isProcessed() {
        return isProcessed;
    }

    public void setProcessed(boolean processed) {
        isProcessed = processed;
    }

    public Order() {
    }

    public Order(String customerName, String productName, int quantity, double price, OrderStatus status, boolean isProcessed) {
        this.customerName = customerName;
        this.product = productName;
        this.quantity = quantity;
        this.price = price;
        this.status = status;
        this.isProcessed = isProcessed;
        //this.orderDate = LocalDateTime.now();
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    //private LocalDateTime orderDate;
}
