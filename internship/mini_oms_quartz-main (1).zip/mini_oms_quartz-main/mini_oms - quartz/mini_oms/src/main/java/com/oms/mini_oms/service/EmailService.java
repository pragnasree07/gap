package com.oms.mini_oms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendOrderCanceledEmail(String to, String customerName, Long orderId, String reason) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("noreply@mini-oms.com"); // or your from email
        message.setTo(to);
        message.setSubject("Order Canceled - Order #" + orderId);
        message.setText("Hello " + customerName + ",\n\n"
                + "Your order with ID " + orderId + " has been canceled.\n"
                + "Reason: " + reason + "\n\n"
                + "Thank you,"
                + "\nMini OMS Support Team");

        mailSender.send(message);
    }
}
