# microservices
sent mail to un-notified for every 2 minutes(using quartz) using an api from the application "mail service".
