package com.example.apis.repository;

import com.example.apis.model.Order;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByStatus(String status);

    @Transactional
    @Modifying
    @Query("UPDATE Order o SET o.status = :status WHERE o.id = :orderId")
    void updateOrderStatus(Long orderId, String status);
}


//package com.example.apis.repository;
//import com.example.apis.model.Order;
//import com.example.apis.model.OrderStatus;
//import jakarta.transaction.Transactional;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;
//
//import java.util.List;
//
//public interface OrderRepository extends JpaRepository<Order, Long> {
//    List<Order> findByStatus(OrderStatus status);
//
//
//    @Transactional
//    @Modifying
//    @Query("UPDATE Order o SET o.status = :status WHERE o.id = :orderId")
//    void updateOrderStatus(Long orderId, String status);
//}
//
//
