package com.example.apis.service;

import org.quartz.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.apis.job.CancelledOrderEmailJob;

@Service
public class SchedulerService {

    private static final Logger logger = LoggerFactory.getLogger(SchedulerService.class);

    @Autowired
    private Scheduler scheduler;

    public void scheduleEmailJob() throws SchedulerException {
        JobKey jobKey = new JobKey("cancelledOrderEmailJob", "email-group");
        TriggerKey triggerKey = new TriggerKey("cancelledOrderEmailTrigger", "email-group");

        if (scheduler.checkExists(jobKey)) {
            logger.info("Job exists. Rescheduling...");
            Trigger newTrigger = TriggerBuilder.newTrigger()
                    .withIdentity(triggerKey)
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                            .withIntervalInMinutes(2)
                            .repeatForever())
                    .build();
            scheduler.rescheduleJob(triggerKey, newTrigger);
        } else {
            logger.info("Job does not exist. Scheduling a new one...");
            JobDetail jobDetail = JobBuilder.newJob(CancelledOrderEmailJob.class)
                    .withIdentity(jobKey)
                    .storeDurably()
                    .build();
            Trigger trigger = TriggerBuilder.newTrigger()
                    .withIdentity(triggerKey)
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                            .withIntervalInMinutes(2)
                            .repeatForever())
                    .build();
            System.out.println("Scheduling CancelledOrderEmailJob...");
            scheduler.scheduleJob(jobDetail, trigger);
            System.out.println("Job scheduled successfully!");

        }
    }
}
