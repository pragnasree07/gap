package com.example.apis.config;
import com.example.apis.service.SchedulerService;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JobInitializer {

    @Bean
    public ApplicationRunner scheduleJobOnStartup(SchedulerService schedulerService) {
        return args -> {
            System.out.println("Initializing job scheduling...");
            schedulerService.scheduleEmailJob();
        };
    }
}

