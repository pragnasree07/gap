//package com.example.apis.service;
//
//import com.example.apis.model.CanceledOrder;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.web.reactive.function.client.WebClient;
//
//@Service
//public class MailService {
//
//    private final WebClient webClient;
//
//    @Autowired
//    public MailService(WebClient.Builder webClientBuilder) {
//        this.webClient = webClientBuilder.baseUrl("http://localhost:8081").build();
//    }
//
//    public void sendCancellationEmail(CanceledOrder order) {
//        try {
////            webClient.post()
////                    .uri("/send-email")
////                    .bodyValue(order)
////                    .retrieve()
////                    .bodyToMono(Void.class)
////                    .doOnSuccess(response -> System.out.println("Email sent for order: " + order.getId()))
////                    .doOnError(error -> System.err.println("Failed to send email: " + error.getMessage()))
////                    .subscribe();
//            webClient.post()
//                    .uri("/send-email")
//                    .bodyValue(order)
//                    .retrieve()
//                    .bodyToMono(Void.class)
//                    .doOnSuccess(response -> System.out.println("Email sent successfully for order: " + order.getId()))
//                    .doOnError(error -> System.err.println("Error sending email: " + error.getMessage()))
//                    .subscribe();
//
//        } catch (Exception e) {
//            System.err.println("Exception while sending email: " + e.getMessage());
//        }
//    }
//}
