package com.example.apis.model;

public enum OrderStatus {
    PENDING,
    PROCESSING,
    SHIPPED,
    COMPLETED,
    CANCELED
}


//package com.example.apis.model;
//public enum OrderStatus {
//    PENDING,
//    PROCESSING,
//    SHIPPED,
//    COMPLETED,
//    CANCELED
//}
//
