package com.example.apis.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
@Entity
@Table(name = "canceled_orders")
public class CanceledOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Reference to the original order id
    private Long orderId;

    // Order details
    private String customerName;
    private String customerEmail;
    private double price;
    private int quantity;

    private LocalDateTime cancelledAt;

    // Indicates whether a notification email has been sent
    private boolean notified = false;
}
