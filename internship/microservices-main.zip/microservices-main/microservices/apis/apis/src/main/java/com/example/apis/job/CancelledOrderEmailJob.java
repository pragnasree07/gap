package com.example.apis.job;

import com.example.apis.model.CanceledOrder;
import com.example.apis.repository.CanceledOrderRepository;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Component
public class CancelledOrderEmailJob extends QuartzJobBean implements ApplicationContextAware {

    private static final Logger logger = LoggerFactory.getLogger(CancelledOrderEmailJob.class);

    private static ApplicationContext applicationContext;
    private CanceledOrderRepository canceledOrderRepository;
    private WebClient.Builder webClientBuilder;

    @Override
    public void setApplicationContext(ApplicationContext context) throws BeansException {
        applicationContext = context;
    }

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        if (canceledOrderRepository == null) {
            canceledOrderRepository = applicationContext.getBean(CanceledOrderRepository.class);
        }
        if (webClientBuilder == null) {
            webClientBuilder = applicationContext.getBean(WebClient.Builder.class);
        }

        System.out.println("Running Quartz job");
        List<CanceledOrder> unnotifiedOrders = canceledOrderRepository.findByNotifiedFalse();

        for (CanceledOrder order : unnotifiedOrders) {
            try {
                System.out.println("Attempting to send email for order: " + order);
                System.out.println("sending cancellation email");

                sendCancellationEmail(order);
                order.setNotified(true);
                canceledOrderRepository.save(order);
                System.out.println("sent email");
                logger.info("Email sent successfully for order ID: {}", order.getId());
            } catch (Exception e) {
                logger.error("Error sending email for order ID {}: {}", order.getId(), e.getMessage());
            }
        }
    }

    private void sendCancellationEmail(CanceledOrder order) {
        WebClient webClient = webClientBuilder.build();
        webClient.post()
                .uri("http://localhost:8081/send-mail")
                .bodyValue(order)
                .retrieve()
                .bodyToMono(Void.class)
                .doOnError(error -> logger.error("Error sending email: {}", error.getMessage()))
                .subscribe();
    }
}
//pathparam
//queryparam
//requestparam