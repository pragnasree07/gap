package com.example.apis.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Order details
    private String customerName;
    private String customerEmail;
    private double price;
    private int quantity;

    // We store status as a String here; you can also use an enum type.
    private String status; // e.g., NEW, CANCELED, etc.
    private LocalDateTime orderDate;
}

