package com.example.mailservice.controller;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;

@RestController
public class TestMailController {
    @Autowired
    private JavaMailSender mailSender;

    @GetMapping("/test-mail")
    public ResponseEntity<String> sendTestMail() {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, StandardCharsets.UTF_8.toString());
            helper.setSubject("Test Email");
            helper.setText("This is a test email.", true);
            helper.setFrom("pragnapallam0210@gmail.com");
            helper.setTo("pragnasreepallam@gmail.com");
            mailSender.send(message);
            return ResponseEntity.ok("Test email sent successfully.");
        } catch (MessagingException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error sending test email: " + e.getMessage());
        }
    }
}

