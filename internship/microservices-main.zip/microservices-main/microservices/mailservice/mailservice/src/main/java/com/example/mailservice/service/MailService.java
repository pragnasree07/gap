package com.example.mailservice.service;

import com.example.mailservice.payload.MailRequest;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import java.nio.charset.StandardCharsets;

@Service
public class MailService {

    @Autowired
    private JavaMailSender mailSender;

    public boolean sendMail(MailRequest request) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, StandardCharsets.UTF_8.toString());
            helper.setSubject("Your Order Has Been Cancelled");

            String text = "Dear " + request.getCustomerName() + ",<br/><br/>" +
                    "Your order (ID: " + request.getOrderId() + ") has been cancelled.<br/>" +
                    "Price: " + request.getPrice() + "<br/>" +
                    "Quantity: " + request.getQuantity() + "<br/><br/>" +
                    "Thank you.";
            helper.setText(text, true);
            helper.setFrom("pragnapallam0210@gmail.com");  // Update with your sender email
            helper.setTo(request.getCustomerEmail());
            mailSender.send(message);
            return true;
        } catch (MessagingException e) {
            e.printStackTrace();
            return false;
        }
    }
}

