package com.example.mailservice.controller;


import com.example.mailservice.payload.MailRequest;
import com.example.mailservice.payload.MailResponse;
import com.example.mailservice.service.MailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class MailController {

    @Autowired
    private MailService mailService;

    @PostMapping("/send-mail")
    public ResponseEntity<MailResponse> sendMail(@RequestBody MailRequest request) {
        boolean result = mailService.sendMail(request);
        if (result) {
            return ResponseEntity.ok(new MailResponse("Email sent successfully."));
        } else {
            return ResponseEntity.status(500).body(new MailResponse("Failed to send email."));
        }
    }
}
